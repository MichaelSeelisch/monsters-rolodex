#ifndef NODE_HTTP_PARSER
#define NODE_HTTP_PARSER

#include <v8.h>

namespace node {

void InitHttpParser(v8::Handle<v8::Object> target);

}

#endif  // NODE_HTTP_PARSER

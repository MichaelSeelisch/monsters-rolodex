require('../common');

console.log('hello world');

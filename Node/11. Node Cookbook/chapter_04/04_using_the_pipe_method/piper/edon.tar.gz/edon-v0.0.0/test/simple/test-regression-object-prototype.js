var sys = require('sys');

//console.log('puts before');

Object.prototype.xadsadsdasasdxx = function () {
};

console.log('puts after');

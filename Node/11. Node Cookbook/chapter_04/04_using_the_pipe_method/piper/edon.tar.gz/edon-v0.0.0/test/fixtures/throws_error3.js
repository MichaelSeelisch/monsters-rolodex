process.nextTick(function () {
  JSON.parse(undefined);
});

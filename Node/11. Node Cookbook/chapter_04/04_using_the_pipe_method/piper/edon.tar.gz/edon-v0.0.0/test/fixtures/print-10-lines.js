puts = require('sys').puts;
for (var i = 0; i < 10; i++) {
  console.log('count ' + i);
}
